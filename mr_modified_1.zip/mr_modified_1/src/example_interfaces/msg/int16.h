// generated from rosidl_generator_c/resource/idl.h.em
// with input from example_interfaces:msg/Int16.idl
// generated code does not contain a copyright notice

#ifndef EXAMPLE_INTERFACES__MSG__INT16_H_
#define EXAMPLE_INTERFACES__MSG__INT16_H_

#include "example_interfaces/msg/detail/int16__struct.h"
#include "example_interfaces/msg/detail/int16__functions.h"
#include "example_interfaces/msg/detail/int16__type_support.h"

#endif  // EXAMPLE_INTERFACES__MSG__INT16_H_
